<div class="row">
	<div class="col-sm-8 col-sm-offset-2 col-xs-12">
		<h1 class="page__title entry-title"><?php the_title(); ?></h1>
	</div>
</div>
